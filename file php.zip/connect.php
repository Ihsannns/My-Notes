<?php
define('host','localhost');
define('user','id12502011_gunawan');
define('pass','Master123');
define('db', 'id12502011_notes');

$con = mysqli_connect(host,user,pass,db) or die("unable to connect");
?>