<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $id = $_POST['id'];
    
    require_once('connect.php');
    
    $sql = "delete from notes where id='$id'";
    
    if(mysqli_query($con, $sql)){
        $response['success'] = true;
        $response['message'] = "Berhasil dihapus";
    }else{
        $response['success'] = false;
        $response['message'] = "Gagal dihapus";
    }
}else{
    $response['success'] = false;
    $response['message'] = "Terjadi Kesalahan";
}

echo json_encode($response);

mysqli_close($con);
?>