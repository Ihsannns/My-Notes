<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $title = $_POST['title'];
    $note = $_POST['note'];
    $color = $_POST['color'];
    
    require_once('connect.php');
    
    $sql = "insert into notes (title,note,color) values ('$title','$note','$color')";
    
    if(mysqli_query($con, $sql)){
        $response['success'] = true;
        $response['message'] = "Berhasil menambahkan";
    }else{
        $response['success'] = false;
        $response['message'] = "Gagal menambahkan";
    }
}else{
    $response['success'] = false;
    $response['message'] = "Terjadi Kesalahan";
}

echo json_encode($response);

mysqli_close($con);
?>