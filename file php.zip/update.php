<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $id = $_POST['id'];
    $title = $_POST['title'];
    $note = $_POST['note'];
    $color = $_POST['color'];
    
    require_once('connect.php');
    
    $sql = "update notes set title='$title',note='$note',color='$color' where id='$id'";
    
    if(mysqli_query($con, $sql)){
        $response['success'] = true;
        $response['message'] = "Berhasil menambahkan";
    }else{
        $response['success'] = false;
        $response['message'] = "Gagal menambahkan";
    }
}else{
    $response['success'] = false;
    $response['message'] = "Terjadi Kesalahan";
}

echo json_encode($response);

mysqli_close($con);
?>